//
//  DeviceDetails.m
//  DenizBankingApp1
//
//  Created by Youssefmyh on 7/7/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "DeviceDetails.h"
#import "KeychainItemWrapper.h"
//4166 3802 5832 2534   4688

@implementation DeviceDetails

+(NSString*) loadPreferences{

        NSString *appName=[[[NSBundle mainBundle] infoDictionary] objectForKey:(NSString*)kCFBundleNameKey];
    //
 
        KeychainItemWrapper* keychain = [[KeychainItemWrapper alloc] initWithIdentifier:
                                         appName
                                                                            accessGroup:nil];
    //

    
    if ([keychain objectForKey:( id)kSecValueData]==nil || [[keychain objectForKey:( id)kSecValueData] isEqualToString:@""] )
        {
            [keychain setObject:[[[UIDevice currentDevice] identifierForVendor] UUIDString] forKey:( id)kSecValueData];
            [keychain setObject:[[[UIDevice currentDevice] identifierForVendor] UUIDString] forKey:( id)kSecAttrAccount];
            
        }
    
    return [keychain objectForKey:( id)kSecValueData];
    
}

+(NSString *)getDeviceIdentifier
{
	
    if (TARGET_IPHONE_SIMULATOR) {
        return @"60049939-F083-4212-AC24-3CA12BC1AF89";
    }
    else
    {
        return [DeviceDetails loadPreferences];
    }
    
}

@end
