//
//  ViewController.m
//  TstStaticID
//
//  Created by Burhan on 2/23/17.
//  Copyright © 2017 Burhan. All rights reserved.
//

#import "ViewController.h"
#import "DeviceDetails.h"

@interface ViewController ()
- (IBAction)buttonClicked:(id)sender;

@end

@implementation ViewController

@synthesize lblUDID;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)buttonClicked:(id)sender {
    
   lblUDID.text = [DeviceDetails getDeviceIdentifier];
}
@end
