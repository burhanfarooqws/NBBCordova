//
//  DeviceDetails.h
//  DenizBankingApp1
//
//  Created by Youssefmyh on 7/7/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#import <Foundation/Foundation.h>



@interface DeviceDetails : NSObject {

}
+(NSString *)getDeviceIdentifier;

@end
