//
//  ViewController.h
//  TstStaticID
//
//  Created by Burhan on 2/23/17.
//  Copyright © 2017 Burhan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblUDID;
@property (weak, nonatomic) IBOutlet UIButton *btnGetUDID;

@end

